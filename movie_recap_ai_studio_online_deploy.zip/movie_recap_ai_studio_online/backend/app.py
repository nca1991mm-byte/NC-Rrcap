import os
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

APP_VERSION = "0.2.0"
ROOT = Path(__file__).resolve().parent
WORK = Path(os.environ.get("WORK_DIR", str(ROOT / "work")))
WORK.mkdir(parents=True, exist_ok=True)

MAX_VIDEO_MB = max(10, int(os.environ.get("MAX_VIDEO_MB", "100")))
MAX_LOGO_MB = max(1, int(os.environ.get("MAX_LOGO_MB", "15")))
MAX_DURATION_SECONDS = max(60, int(os.environ.get("MAX_DURATION_SECONDS", "300")))
MAX_CONCURRENT_RENDERS = max(1, int(os.environ.get("MAX_CONCURRENT_RENDERS", "1")))
ALLOWED_ORIGINS = [
    origin.strip().rstrip("/")
    for origin in os.environ.get(
        "CORS_ORIGINS",
        "https://movie-recap-ai-studio.onrender.com,http://localhost:5500,http://127.0.0.1:5500"
    ).split(",")
    if origin.strip()
]
RENDER_SLOTS = threading.BoundedSemaphore(MAX_CONCURRENT_RENDERS)

app = FastAPI(
    title="Movie Recap AI Studio API",
    version=APP_VERSION,
    docs_url="/docs" if os.environ.get("ENABLE_API_DOCS", "false").lower() == "true" else None,
    redoc_url=None,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "X-App-Token"],
)

RATIOS = {
    "16:9": (1920, 1080), "9:16": (1080, 1920),
    "1:1": (1080, 1080), "4:3": (1440, 1080), "3:4": (1080, 1440)
}
FORMATS = {"MP4": ("mp4", "video/mp4"), "WebM": ("webm", "video/webm")}
VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi"}
LOGO_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
last_requests = {}
RATE_LIMIT_WINDOW = 60
RATE_LIMIT_MAX = max(1, int(os.environ.get("RATE_LIMIT_PER_MINUTE", "5")))

def cleanup(path: Path):
    shutil.rmtree(path, ignore_errors=True)

def run_command(args, timeout):
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError:
        raise HTTPException(500, "Server တွင် FFmpeg/FFprobe မရှိပါ။")
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Render အချိန်ကျော်သွားပါသည်။ ပိုတိုသော Video ဖြင့် စမ်းပါ။")
    if result.returncode:
        # Avoid returning full command lines or server filesystem paths.
        detail = (result.stderr or "Unknown media processing error")[-1000:]
        raise HTTPException(400, "Video processing မအောင်မြင်ပါ။ ဖိုင် format ကို စစ်ပါ။ " + detail)
    return result

def require_app_token(request: Request):
    expected = os.environ.get("APP_ACCESS_TOKEN", "").strip()
    if not expected:
        raise HTTPException(503, "Server တွင် APP_ACCESS_TOKEN မသတ်မှတ်ရသေးပါ။")
    supplied = request.headers.get("X-App-Token", "")
    if not supplied or not secrets.compare_digest(supplied, expected):
        raise HTTPException(401, "Access token မမှန်ပါ။ Web UI ထဲရှိ Access Token ကို စစ်ပါ။")

def rate_limit(request: Request):
    # Basic per-process abuse guard. Use a shared rate limiter/WAF for multi-instance production.
    host = request.client.host if request.client else "unknown"
    now = time.time()
    entries = [t for t in last_requests.get(host, []) if now - t < RATE_LIMIT_WINDOW]
    if len(entries) >= RATE_LIMIT_MAX:
        raise HTTPException(429, "တောင်းဆိုမှုများလွန်းနေပါသည်။ တစ်မိနစ်အကြာ ပြန်စမ်းပါ။")
    entries.append(now)
    last_requests[host] = entries

async def save_upload_limited(upload: UploadFile, path: Path, max_bytes: int, allowed_exts: set[str]):
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in allowed_exts:
        raise HTTPException(415, "မထောက်ပံ့သောဖိုင်အမျိုးအစား ဖြစ်ပါသည်။")
    size = 0
    with path.open("wb") as out:
        while True:
            chunk = await upload.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > max_bytes:
                out.close()
                path.unlink(missing_ok=True)
                raise HTTPException(413, f"ဖိုင်အရွယ်အစား ကန့်သတ်ချက် {max_bytes // (1024*1024)} MB ကျော်နေပါသည်။")
            out.write(chunk)
    if size == 0:
        raise HTTPException(400, "ဗလာဖိုင်ကို လက်ခံမရပါ။")
    return suffix

def probe_duration(path: Path) -> float:
    result = run_command([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path)
    ], timeout=30)
    try:
        return float(result.stdout.strip())
    except (ValueError, AttributeError):
        raise HTTPException(400, "Video ကြာချိန်ကို ဖတ်မရပါ။")

@app.get("/health")
def health():
    return {
        "ok": True,
        "service": "Movie Recap AI Studio",
        "version": APP_VERSION,
        "ffmpeg": shutil.which("ffmpeg") is not None,
        "ffprobe": shutil.which("ffprobe") is not None,
        "limits": {"video_mb": MAX_VIDEO_MB, "duration_seconds": MAX_DURATION_SECONDS}
    }

@app.post("/render")
async def render_video(
    request: Request,
    video: UploadFile = File(...),
    aspect: str = Form("16:9"),
    zoom: int = Form(100),
    flip: bool = Form(False),
    color_shift: bool = Form(False),
    mute_original_audio: bool = Form(True),
    resolution: str = Form("1080p"),
    output_format: str = Form("MP4"),
    logo: UploadFile | None = File(None),
    logo_size: int = Form(15),
    logo_position: str = Form("bottom-right"),
    subtitle_text: str = Form(""),
    subtitle_color: str = Form("white"),
    subtitle_size: int = Form(36),
    subtitle_position: str = Form("bottom"),
):
    require_app_token(request)
    rate_limit(request)
    if not RENDER_SLOTS.acquire(blocking=False):
        raise HTTPException(429, "Server က Video တစ်ခုကို Render လုပ်နေပါသည်။ ခဏစောင့်ပြီး ပြန်စမ်းပါ။")
    job = WORK / uuid.uuid4().hex
    job.mkdir(parents=True, exist_ok=False)
    try:
        if aspect not in RATIOS:
            raise HTTPException(422, "aspect တန်ဖိုး မမှန်ပါ။")
        if output_format not in FORMATS:
            raise HTTPException(422, "output_format တန်ဖိုး မမှန်ပါ။")
        if resolution not in {"720p", "1080p", "4K"}:
            raise HTTPException(422, "resolution တန်ဖိုး မမှန်ပါ။")
        if logo_position not in {"top-left", "top-right", "bottom-left", "bottom-right", "center"}:
            raise HTTPException(422, "logo_position တန်ဖိုး မမှန်ပါ။")
        if subtitle_position not in {"top", "middle", "bottom"}:
            subtitle_position = "bottom"

        input_path = job / "input"
        await save_upload_limited(video, input_path, MAX_VIDEO_MB * 1024 * 1024, VIDEO_EXTS)
        duration = probe_duration(input_path)
        if duration <= 0 or duration > MAX_DURATION_SECONDS:
            raise HTTPException(413, f"Video ကြာချိန်သည် {MAX_DURATION_SECONDS // 60} မိနစ်ထက် မကျော်ရပါ။")

        w, h = RATIOS[aspect]
        if resolution == "720p":
            factor = min(1280 / w, 1280 / h)
            w, h = int(w * factor), int(h * factor)
        elif resolution == "4K":
            w, h = w * 2, h * 2
        w, h = max(2, w // 2 * 2), max(2, h // 2 * 2)
        z = max(50, min(200, zoom)) / 100
        if z >= 1:
            filters = [f"scale={w*z:.0f}:{h*z:.0f}:force_original_aspect_ratio=increase", f"crop={w}:{h}"]
        else:
            zw, zh = max(2, int(w*z)//2*2), max(2, int(h*z)//2*2)
            filters = [f"scale={zw}:{zh}:force_original_aspect_ratio=decrease", f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:black"]
        if flip:
            filters.append("hflip")
        if color_shift:
            filters.append("hue=h=25:s=1.25")
        filters.append("setsar=1")

        args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(input_path)]
        logo_path = None
        if logo and logo.filename:
            logo_path = job / "logo"
            await save_upload_limited(logo, logo_path, MAX_LOGO_MB * 1024 * 1024, LOGO_EXTS)
            args += ["-i", str(logo_path)]

        graph = f"[0:v]{','.join(filters)}[base]"
        last = "base"
        if logo_path:
            size = max(3, min(40, logo_size))
            logo_width = max(32, int(w * size / 100))
            positions = {
                "top-left": "24:24", "top-right": "W-w-24:24",
                "bottom-left": "24:H-h-24", "bottom-right": "W-w-24:H-h-24",
                "center": "(W-w)/2:(H-h)/2"
            }
            graph += f";[1:v]scale=w='min({logo_width}\\,iw)':h=-1[logo];[{last}][logo]overlay={positions[logo_position]}[vout]"
            last = "vout"

        if subtitle_text.strip():
            font_path = os.environ.get("MYANMAR_FONT_PATH", "/usr/share/fonts/truetype/noto/NotoSansMyanmar-Regular.ttf")
            escaped = subtitle_text.replace("\\", r"\\").replace(":", r"\:").replace("'", r"\'").replace("%", r"\%").replace(",", r"\,").replace("[", r"\[").replace("]", r"\]")
            y = "h-th-70" if subtitle_position == "bottom" else ("30" if subtitle_position == "top" else "(h-th)/2")
            color = subtitle_color if subtitle_color in {"white", "yellow", "cyan", "lime", "red"} else "white"
            graph += f";[{last}]drawtext=fontfile='{font_path}':text='{escaped}':fontcolor={color}:fontsize={max(12,min(120,subtitle_size))}:borderw=3:bordercolor=black:x=(w-text_w)/2:y={y}[subout]"
            last = "subout"

        out_ext, mime = FORMATS[output_format]
        output_path = job / f"rendered.{out_ext}"
        args += ["-filter_complex", graph, "-map", f"[{last}]"]
        if mute_original_audio:
            args += ["-an"]
        else:
            args += ["-map", "0:a?", "-c:a", "aac"]
        if output_format == "MP4":
            args += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-pix_fmt", "yuv420p", "-movflags", "+faststart"]
        else:
            args += ["-c:v", "libvpx-vp9", "-crf", "34", "-b:v", "0"]
        args += ["-t", str(MAX_DURATION_SECONDS), "-shortest", str(output_path)]
        run_command(args, timeout=min(3600, max(120, int(duration * 5))))
        return FileResponse(
            output_path,
            media_type=mime,
            filename=f"movie-recap-render.{out_ext}",
            background=BackgroundTask(cleanup, job),
        )
    except HTTPException:
        cleanup(job)
        raise
    except Exception:
        cleanup(job)
        raise HTTPException(500, "Render မအောင်မြင်ပါ။ Video format, server log နှင့် font setting ကို စစ်ပါ။")
    finally:
        RENDER_SLOTS.release()
