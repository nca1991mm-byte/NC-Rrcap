# Deployment checklist

- [ ] Code committed to a GitHub repository
- [ ] Render Blueprint deployed
- [ ] API `/health` reports `ffmpeg: true` and `ffprobe: true`
- [ ] Static site URL copied from Render dashboard
- [ ] `CORS_ORIGINS` set to exact static-site origin
- [ ] Backend API URL set in the Web UI Export tab
- [ ] Small test video rendered successfully
- [ ] Burmese subtitle glyphs checked using a real sample
- [ ] Public production auth / quotas / queue planned before broad release
