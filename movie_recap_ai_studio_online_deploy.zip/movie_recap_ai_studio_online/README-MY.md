# Movie Recap AI Studio — Online Website MVP

ဒီ ZIP က Render.com ပေါ်မှာ Web UI နဲ့ FFmpeg backend ကို သီးခြား deploy လုပ်နိုင်ဖို့ ပြင်ဆင်ထားတဲ့ starter package ဖြစ်ပါတယ်။ သင့်အစား account ထဲ login ဝင်ပြီး deploy လုပ်ထားခြင်း မဟုတ်ပါ။

## ပါဝင်သည့်အရာများ
- `web/index.html` — browser Web UI
- `backend/app.py` — FastAPI render API
- `backend/Dockerfile` — FFmpeg ပါဝင်တဲ့ container image
- `render.yaml` — Render Blueprint deploy configuration
- `/health` — backend health check

## အဆင့် ၁ — GitHub Repository ဖန်တီးပါ
1. GitHub မှာ repository အသစ်ဖန်တီးပါ။
2. ZIP ကို unzip လုပ်ပြီး ဖိုင်တွေကို repository root ထဲ upload/commit လုပ်ပါ။
3. `render.yaml`, `web/`, `backend/` တို့ root မှာရှိကြောင်း စစ်ပါ။

## အဆင့် ၂ — Render မှာ Deploy လုပ်ပါ
1. https://render.com ကိုဖွင့်ပြီး GitHub နဲ့ sign in လုပ်ပါ။
2. Dashboard မှ **New → Blueprint** ကိုရွေးပါ။
3. ဒီ repository ကို ချိတ်ဆက်ပြီး `render.yaml` ကို confirm လုပ်ပါ။
4. Blueprint က `movie-recap-ai-api` (Docker backend) နဲ့ `movie-recap-ai-studio` (static site) ကို ဖန်တီးပေးပါမယ်။
5. Deploy ပြီးရင် API service ရဲ့ URL ကိုဖွင့်ပြီး `/health` ကို စစ်ပါ။ `ok: true`, `ffmpeg: true`, `ffprobe: true` ပြရပါမယ်။

> Render service names သို့မဟုတ် domain ကို ပြောင်းထားရင် URL ကွာနိုင်ပါတယ်။ Dashboard ထဲက အမှန်တကယ် URL ကို သုံးပါ။

## အဆင့် ၃ — Web UI ကို Backend နဲ့ ချိတ်ပါ
1. Render Dashboard → `movie-recap-ai-studio` static site → URL ကို ကူးပါ။
2. Backend service → Environment → `CORS_ORIGINS` ထဲမှာ Web site URL ကို အတိအကျ ထည့်ပါ။ URL များစွာရှိရင် comma နဲ့ခွဲပါ။ trailing slash မထည့်ပါနှင့်။
3. Save changes / redeploy လုပ်ပါ။
4. Web site ကိုဖွင့်ပါ → **Export** tab → `Backend API URL` ထဲမှာ backend ရဲ့ URL ကို `https://...` အပြည့်အစုံနဲ့ ထည့်ပါ။
5. Video တိုတစ်ခု Upload လုပ်ပြီး Render & Download Video ကို စမ်းပါ။
6. Browser က CORS error ပြရင် `CORS_ORIGINS` ထဲရှိ domain နဲ့ browser address bar domain တူမတူ စစ်ပါ။

## အဆင့် ၄ — Public release မလုပ်ခင်
- HTTPS သုံးပါ။ Render ရဲ့ HTTPS URL ကိုပဲ သုံးပါ။
- Render Blueprint တွင် `APP_ACCESS_TOKEN` ကို secret environment variable အဖြစ်သတ်မှတ်ထားသည်။ Token ကို HTML source ထဲ မထည့်ပါနှင့်။ Shared token သည် single-owner/private MVP အတွက် အခြေခံကာကွယ်မှုသာဖြစ်ပြီး multi-user product အတွက် login/OAuth, per-user quotas, rotating tokens, distributed rate limiting/WAF နဲ့ audit logs ထပ်ထည့်ပါ။ CORS သည် browser policy သာဖြစ်သည်။
- လက်ရှိ code တွင် upload size, duration, simple per-process rate limit နဲ့ တစ်ကြိမ်တည်း render အတွက် guard များပါသော်လည်း user login, billing/quotas, distributed rate limiting, durable job queue, malware scanning မပါသေးပါ။
- Production အတွက် user authentication / signed job token, persistent queue, object storage, metrics, logs, cleanup policy နဲ့ WAF/rate limiting ထပ်ထည့်ပါ။
- Blueprint ကို အစပိုင်းစမ်းသပ်ရန် free plan ဖြင့် ပြင်ဆင်ထားသည်။ Free instance တွင် CPU/memory/sleep ကန့်သတ်ချက်ရှိနိုင်ပြီး render ကြာနိုင်သည်။ ပိုကြီးသော Video သို့မဟုတ် အမြဲ online အသုံးပြုမှုအတွက် paid plan မရွေးခင် Render ရဲ့ လက်ရှိဈေးနှုန်းကို စစ်ပြီး ကိုယ်တိုင်အတည်ပြုပါ။
- Private API key ကို browser HTML ထဲ မထည့်ပါနှင့်။
- အသုံးပြုခွင့်ရှိသော video နဲ့ voice များကိုသာ upload လုပ်ပါ။

## လက်ရှိကန့်သတ်ချက်
ဒါဟာ Online Web MVP ဖြစ်ပြီး AI Auto Recap, real Myanmar TTS, voice cloning, social link import, full blur layers, freeze-frame rendering နဲ့ AI image generation တို့ကို မချိတ်ဆက်ရသေးပါ။ မြန်မာ Subtitle font rendering ကို deploy ပြီး sample file ဖြင့် စစ်ဆေးပါ။
